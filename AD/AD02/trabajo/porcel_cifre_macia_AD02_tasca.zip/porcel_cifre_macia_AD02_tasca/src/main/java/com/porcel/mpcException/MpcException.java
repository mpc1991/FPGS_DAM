package com.porcel.mpcException;

public class MpcException extends java.lang.Exception {
    public MpcException() {}
    public MpcException(String message) {super(message);}
}
