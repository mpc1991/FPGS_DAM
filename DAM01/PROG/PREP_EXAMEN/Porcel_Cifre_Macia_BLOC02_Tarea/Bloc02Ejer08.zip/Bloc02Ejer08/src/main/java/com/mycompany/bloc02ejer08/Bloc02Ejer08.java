/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer08;

/**
 * Este código en Java es una calculadora básica que permite al usuario realizar
 * operaciones de suma, resta, multiplicación y división. 
 * El programa solicita dos números y luego presenta un menú con las opciones disponibles. Después de
 * realizar una operación, el usuario puede elegir otra opción o salir del programa.
 * 
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;
import java.util.InputMismatchException;
public class Bloc02Ejer08 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x;
        int y;
        
        try{
            System.out.print("Ingrase el primer número: ");
            x = in.nextInt();
            System.out.print("Ingrese el segundo número: ");
            y = in.nextInt ();
        
            int opcion;
            do{
                // Mostrar el menú de opciones y obtener la opción elegida
                opcion = menu();
        
                // Realizar la operación correspondiente según la opción elegida
                switch(opcion) {
                    case 1: //Sumar
                        int suma = sumar(x, y);
                        System.out.println("La suma es: " + suma);
                        break;
                    case 2: // Restar
                        int resta = restar(x, y);
                        System.out.println("La resta es: " + resta);
                        break;
                    case 3: // Multiplicar
                        int multiplicacion = multiplicar(x,y);
                        System.out.println("La multiplicación es: " + multiplicacion);
                        break;
                    case 4: //Dividir
                        if (y == 0) {
                            System.out.println("Error: No se puede dividir por 0");
                            return;
                        }
                        double division = dividir(x,y);
                        System.out.println ("La división es: " +division);
                        break;
                    case 5: //Salir del programa
                        System.out.println("Hasta pronto!");
                        break;
                    default: //Opción no válida
                        System.out.println("Opción no válida. Por favor, elija una opción del 1 al 5.");
                        return;
                }
            } while (opcion != 5);
        } catch (InputMismatchException e){
            System.out.println("Error: ingrese números enteros.");
        }
    }
        
    public static int menu(){
        Scanner in = new Scanner(System.in);
        System.out.print("1. sumar.\n2. Restar.\n3. Multiplicar.\n4. Dividir.\n5. Salir del programa.\n\nSeleccione la operación a realizar: \n");
        int menuOpt = in.nextInt();
        return menuOpt;
    }
        
    public static int sumar(int x, int y){
        int resultadoSuma = x + y;
        return resultadoSuma;
    }
        
    public static int restar(int x, int y){
        int resultadoResta = x - y;
        return resultadoResta;
    }
        
    public static int multiplicar (int x, int y){
        int resultadoMultiplicacion = x*y;
        return resultadoMultiplicacion;
    }
        
    public static double dividir(double x, double y){
        double resultadoDivision = x / y;
        return resultadoDivision;
    }
}
