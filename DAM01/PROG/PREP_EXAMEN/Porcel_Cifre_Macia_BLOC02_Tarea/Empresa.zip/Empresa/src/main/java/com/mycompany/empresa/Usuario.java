/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.empresa;

/**
 * Esta clase Usuario en Java define un modelo para representar a un usuario con
 * atributos privados como nombre y edad. 
 * Incluye constructores por defecto y con parámetros, así como métodos para 
 * obtener y establecer valores (getters y setters). También proporciona métodos
 * para calcular la edad dentro de una década y clasificar la edad en rangos.
 * 
 * @author Macia Porcel Cifre
 */
public class Usuario {
    //Atributos privados
    private String nombre;
    private int edad;

    //Constructor por defecto
    public Usuario(){
            this.nombre = "Empty";
            this.edad = 0;
    }
    
    //Constructor con parámetros
    public Usuario (String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
        
    //Getters
    public String getNombre(){
        return nombre;
    }

    public int getEdad(){
        return edad;
    }
        
    //Setters
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
        
    public void setEdad(int edad){
        this.edad = edad;
    }
    
    // Calcular edad en una decada
    public int calcularEdadDecada(){
        //Decada actual
        int decadaActual = (getEdad()+10);
        
        //Devolver la edad dentro de la decada
        return decadaActual;
    }
    
    // Clasificar la edad
    public char clasificar() {
        if (edad >= 0 && edad <= 25){
            return 'A';
        } else if (edad >= 26 && edad <=50){
            return 'B';
        } else {
            return 'C';
        }
    } 
}
