/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.empresa;

/**
 * Este código en Java implementa una pequeña simulación de una empresa que
 * utiliza la clase Usuario. 
 * Se crean dos instancias de la clase Usuario para representar a dos empleados. 
 * El programa muestra información sobre su clasificación de edad y la edad que 
 * tendrán dentro de una década.
 * 
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;
public class Empresa {

    public static void main(String[] args) {
    Scanner in = new Scanner (System.in);
    
    // Empieza usuario1
    // Usuario con constructor de parámetros
    Usuario usuario1 = new Usuario("Maria", 26);
    
    // Mensaje usando calcularEdadDecada y Clasificar - Primer usuario
    System.out.println(usuario1.getNombre() + ", estás clasificada como " + usuario1.clasificar() + " y dentro de una década tendrás " + usuario1.calcularEdadDecada() + " años");
    
    //----------------------------------------------------------------------------------------------
    
    // Empieza usuario2
    //Solicitar nombre y edad por teclado
    System.out.print("Introduce tu nombre: ");
    String nombre = in.nextLine();
    System.out.print("Introduce tu edad: ");
    int edad = in.nextInt();
    
    // Crear un objeto de la clase Usuario con constructor por defecto
    Usuario usuario2 = new Usuario();
    usuario2.setNombre(nombre);
    usuario2.setEdad(edad);
    
    //Mensaje utilizando calcularEdadDecada y clasificar - Segundo usaurio
    System.out.println(usuario2.getNombre() + ", estás clasificad@ como " + usuario2.clasificar() + " y dentro de una década tendrás " + usuario2.calcularEdadDecada() + " años");
    
    }
}

