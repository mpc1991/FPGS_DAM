/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer02;

/**
 * Este código en Java te ayuda a encontrar la suma de los primeros múltiplos de 5. 
 * Ingresa cuántos términos quieres sumar, y el programa hará el resto.
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;

public class Bloc02Ejer02 {
    
    public static void main(String[] args) {
    int i,n,sum=0; // Declaramos tres variables int
    
    System.out.print("Input number of terms is: "); 
        { 
            Scanner in = new Scanner(System.in); // Solicitamos un número por pantalla
                n = in.nextInt(); //capturamos el número en la variable "n"
                
            System.out.print("La suma de los " +n+ " primeros múltiplos de 5 es: ");
            for (i=1;i<=n;i++) {            
                sum+=5*i; // Calcula el múltiplo de 5 actual
                System.out.print (5*i);
                    if (i < n){
                        System.out.print(" + ");
                    }
                }            
        }
        System.out.println (" = " +sum);
    }
}
