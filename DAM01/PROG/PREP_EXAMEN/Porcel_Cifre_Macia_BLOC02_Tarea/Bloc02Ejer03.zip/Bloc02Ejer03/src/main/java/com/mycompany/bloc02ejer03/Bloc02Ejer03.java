/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer03;

/**
 * Este código en Java cuenta el número de palabras en una frase que ingreses.
 * Escribe tu frase, y el programa te dirá cuántas palabras contiene
 * @author Macià Porcel Cifre
 */
import java.util.Scanner;

public class Bloc02Ejer03 {

    public static void main(String[] args) {
        String cadena; //Variable que contiene la frase
        int count=0; //Variable que va a contar el número de palabras
        Scanner in = new Scanner(System.in);
        
        System.out.println("Escribe tu frase: ");
        cadena = in.nextLine(); // Capturamos la frase
        
        // Si no se ha indicado nada, exponemos aviso y terminamos
        if (cadena.isEmpty()){
            System.out.print("La frase no tiene ninguna palabra");
        } else {
            String cadenaMayus=cadena.toUpperCase(); //Convertimos la frase a mayúsculas
        
            // Inicializamos el índice de inicio
            int startIndex = 0;
            int spaceIndex;
            
            // Bucle para encontrar y mostrar cada palabra
            while ((spaceIndex = cadenaMayus.indexOf(' ', startIndex)) != -1) {
                // Extraer la palabra actual
                String palabra = cadenaMayus.substring(startIndex, spaceIndex);
                //Mostrar la palabra actual con un salto de línea
                System.out.print(palabra + "\n");
                // Actualizar el índice para la proxima palabra
                startIndex = spaceIndex + 1;
                // Incrementar el contador de palabras
                count++;
            }
            
            // Última palabra después del último espacio en blanco
            String ultimaPalabra = cadenaMayus.substring(startIndex);
            System.out.println(ultimaPalabra);
            count++;
            
            // Mostrar el total de palabras
            System.out.print("La frase tiene " +count+" palabras");
        }
    }
}
