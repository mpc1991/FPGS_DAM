/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer05;

/**
 * Este código en Java utiliza un tipo enumerado para representar diferentes razas de perros. 
 * El programa te solicita ingresar la raza del perro por teclado y luego utiliza
 * el tipo enumerado para mostrar la raza elegida en un formato más legible.
 * 
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;
public class Bloc02Ejer05{
    public static void main(String[] args){
    
        //Tipo enumerado de rafa
        enum Raza {
        MASTIN,
        TERRIER,
        BULLDOG,
        PASTOR_ALEMAN,
        PASTOR_MALLORQUIN,
        CANICHE,
        GALGO,
        }
        
        Raza perro;
        String razaElegida;
        
        //Introducción de la raza por teclado
        Scanner in = new Scanner(System.in);
        System.out.println("Introduce la raza del perro: ");
        razaElegida=in.nextLine();
        
        //Capturamos excepcion
        try{
            perro = Raza.valueOf(razaElegida.toUpperCase().replaceAll(" ", "_"));
        } catch (IllegalArgumentException e) {
            System.out.println("La raza introducida no es válida.");
            return;
        }
        
        //Resultado
        System.out.println("La raza elegida es: " +perro);
    }
}



