/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer01;

/**
 * Este código en Java te ayuda a resolver ecuaciones cuadráticas. 
 * Ingresa los valores de a, b y c, y el programa te dará las raíces reales de la ecuación. 

 * @author Macia Porcel Cifre
 */

import java.util.Scanner;
public class Bloc02Ejer01 {
    public static void main(String[] Strings){
    
        Scanner input = new Scanner(System.in);
        
            System.out.print("Input a: ");
            double a = input.nextDouble();
            System.out.print("Input b: ");
            double b = input.nextDouble();
            System.out.print("Input c: ");
            double c = input.nextDouble();
            
            double result = b*b -4.0 * a * c;
            
            if (result > 0.0) {
                // Elevar la potencia por 0.5 es lo mismo que calcular la raíz cuadrada
                // Al modificar Math.pow por Math.sqrt ya no es necesario ese paso
                double r1 = (-b + Math.sqrt(result)) / (2.0 *a);
                double r2 = (-b - Math.sqrt(result)) / (2.0 * a);
                System.out.println("The roots are " +r1 + "and " + r2);
            } else if (result == 0.0) {
                double r1 = -b / (2.0 *a);
                System.out.println("The root is " + r1);
            } else {
                System.out.println("The equation has no real roots.");
            }
            
    }

}
