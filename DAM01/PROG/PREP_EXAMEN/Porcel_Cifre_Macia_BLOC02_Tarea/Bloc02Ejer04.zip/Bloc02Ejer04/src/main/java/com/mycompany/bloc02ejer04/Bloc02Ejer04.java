/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer04;

/**
 * Este código en Java implementa un juego de adivinanza.
 * Selecciona un rango de números, genera un número aleatorio dentro de ese rango y 
 * te desafía a adivinarlo en un máximo de 10 intentos.
 *
 * @author Macia Porcel Cifre
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class Bloc02Ejer04 {

    public static void main(String[] args) {
        int x,y,t,intento,maxIntento=10; //Variables 
        Scanner in = new Scanner(System.in);
        
        //Solicitamos ingresar los números
        try {
            System.out.println("Elige el número inicial: ");
            x = in.nextInt();
            System.out.println("Elige el número final: ");
            y = in.nextInt();
            if (y <= x){
                System.out.println("Debes ingresar un número final mayor que el inicial");
                return;
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingresa números enteros válidos.");
            return;
        }
        
        // generamos número aleatorio
        int randomNum = (int) (Math.random()* (y-x+1)+x);
        
        // Introducción al juego
        System.out.println("Adivina el número entre [" +x+ "] y [" +y+ "]");
        
        // Realizamos los intentos
        for (intento=1; intento <= maxIntento; intento++){
            System.out.println("Introduce tu intento número " +intento+" para comenzar");
            t = in.nextInt();
            
            try {
                //Comprobamos los intentos
                if (t == randomNum){
                    System.out.println("Felicidades, adivinastes el número!");
                    System.out.println("El número de intentos usados es: " +intento);
                    return;
                } else if (t < randomNum){
                    System.out.println("El número elegido es inferior al correcto.\nEl número de intentos usados es: " +intento);
                } else if (t > randomNum){
                    System.out.println("El número elegido es superior al correcto.\nEl número de intentos usados es: "+intento);
                }
            } catch (InputMismatchException e){
                System.out.println("Error: Ingresa un número entero válido.");
            }
        }
        if (intento > maxIntento) {
                    System.out.println("Has agotado todos tus intentos, el número era: " +randomNum);
                    return;
        }
    }
}
