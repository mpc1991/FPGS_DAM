/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer06;

/**
 * Este código en Java determina el número más pequeño entre dos valores que el usuario ingresa
 * @author Macia Porcel Cifre
 */

// Para ver qué se ha modificado se han dejado comentadas las líneas del código original
import java.util.Scanner;

public class Bloc02Ejer06 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input the first number: "); // Pedimos el primer número
        double x = in.nextDouble(); // Capturamos el primer número en la variable x
        System.out.print("Input the Second number: "); // Pedimos el segundo número
        double y = in.nextDouble(); // Capturamos el segundo número en la variable y
        //System.out.print("Input the third number: ");
        //double z = in.nextDouble();
        //System.out.print("The smallest value is " + smallest(x, y,z)+"\n");
        if (x == y){ // Si son iguales lo indicamos por pantalla y terminamos el código
        System.out.print("Los números son iguales");
        } else  // Si no son iguales llamamos a el método estático
            System.out.print("El número más pequeño es: " +smallest(x, y)); 
    }
    
    //public static double smallest(double x, double y, double z){
    public static double smallest(double x, double y){
        if (x<y){
            return x; // Devolvemos x se este número es más pequeño
        } else {
            return y; // De lo contrario devolvemos y
        }
        //return Math.min(Math.min(x, y), z);
    }
}
