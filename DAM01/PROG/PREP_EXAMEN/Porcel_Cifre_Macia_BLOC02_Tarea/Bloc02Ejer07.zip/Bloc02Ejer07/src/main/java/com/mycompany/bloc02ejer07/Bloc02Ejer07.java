/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer07;

/**
 * Este código en Java genera y muestra una secuencia de números pentagonales.
 * Solicita al usuario la cantidad de números pentagonales que desea ver y luego
 * imprime la secuencia en un formato fácil de leer.
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;
public class Bloc02Ejer07 {

    public static void main(String[] args) {
        int count = 1;
        Scanner in = new Scanner (System.in);
        System.out.println("Que cantidad de números pentagonales deben presentarse? ");
        int x = in.nextInt();
        
        for (int i = 1; i <= x; i++){
            System.out.printf("%-6d",getPentagonalNumber(i));
            if (count % 10 == 0) System.out.println();
            count++;
        }
    }

    public static int getPentagonalNumber(int i){
        return (i * (3* i -1))/2;
    }
}
