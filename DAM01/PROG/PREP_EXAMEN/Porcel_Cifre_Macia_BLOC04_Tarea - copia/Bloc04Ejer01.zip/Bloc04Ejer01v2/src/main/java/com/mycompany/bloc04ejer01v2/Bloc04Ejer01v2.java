package com.mycompany.bloc04ejer01v2;

/**
 * Programa que cuenta el número de ocurrencias de una letra específica en una frase proporcionada por el usuario. 
 * @author Macià Porcel Cifre
 */
import java.util.Scanner;
import java.text.Normalizer; // Lo usaremos para normalizar letras y quitarles acentos.

public class Bloc04Ejer01v2 {
    private static Scanner scanner = new Scanner(System.in, "ISO-8859-1"); // Añadimos el encoding para el input.
    
    public static void main(String[] args) {
        String inputPhrase = inputPhrase(); // Llamamos al método "inputPhrase" para que nos devuelva la frase introducida
        char inputLetter = inputLetter(); // Llamamos al método "inputLetter" para que nos devuelva la letra o caracter introducido
        int coincidences = coincidences(inputPhrase, inputLetter); //contamos las veces que se repite la letra dentro de la frase
        
        if (coincidences != 0) { // Si hay una o más coincidencias informamos del resultado por pantalla
            System.out.println("La letra \"" + inputLetter + "\" aparece " + coincidences + " veces en la frase");
        } else { //Si no hay coincidencias, informamos por pantalla de que la letra no aparece en la frase
            System.out.println("La letra \"" + inputLetter + "\" no aparece en la frase.");
        }
    }

    private static String inputPhrase() {
        // Pedimos la frase por teclado
        System.out.println("Bienvenido al nuevo modelo de contador de letras");
        System.out.println("Para empezar, introduzca su frase:");
        String inputFrase = scanner.nextLine(); //Almacenamos la frase
        return inputFrase; // devolvemos la frase
    }

    private static char inputLetter() {
        // Pedimos la letra por teclado
        System.out.println("Ahora indique la letra que quiere contar (Si añade más de una, sólo se tendrá en cuenta la primera):");
        char inputLetter = scanner.next().charAt(0); //Almacenamos la primera letra o caracter introducido
        return inputLetter; //devolvemos la letra
    }
    
    private static int coincidences(String phrase, char letter){
        // Creamos la variable donde vamos a almacenar el número de repeticiones
        int count = 0;
        String fraseNormalizada = Normalizer.normalize(phrase, Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", ""); //quitamos acentos.
        
        // Revisamos las coincidencias
        for (int i =0; i<fraseNormalizada.length();i++) {
            char currentChar = fraseNormalizada.charAt(i);
            if (Character.toLowerCase(currentChar) == Character.toLowerCase(letter)){ //comprobamos ambas cadenas en minúscula para evitar diferenciar mayúsculas de minúsculas
            count++;
            }
        }
        return count; // Devolvemos la cantidad de coincidencias
    }
}

