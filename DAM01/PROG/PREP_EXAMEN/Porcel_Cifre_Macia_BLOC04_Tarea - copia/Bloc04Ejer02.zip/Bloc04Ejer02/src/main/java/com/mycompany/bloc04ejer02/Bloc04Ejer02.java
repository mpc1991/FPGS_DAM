package com.mycompany.bloc04ejer02;

/**
 * este código se encarga de solicitar al usuario 8 cadenas de texto en un formato específico (cuatro letras seguidas de un guion y tres números), validando 
 * que cumplan con este formato mediante expresiones regulares. 
 * Luego, genera un array de booleanos indicando si cada cadena empieza con la letra 'T' o no. 
 * Finalmente, muestra en pantalla las cadenas junto con un indicador de si empiezan con 'T' o no, presentando los resultados en un formato tabulado.
 * 
 * @author Macia Porcel
 */
import java.util.Scanner;

public class Bloc04Ejer02 {
    private static Scanner scanner = new Scanner(System.in);
    private static final int TAMANO_ARRAY = 8;
    
    public static void main(String[] args) {
        String[] cadenasValidas = new String [TAMANO_ARRAY];
        boolean[] numerosValidos = new boolean [TAMANO_ARRAY];
        
        // Almacenar las 8 cadenas de String válidas en el array
       for (int i = 0; i< TAMANO_ARRAY; i++){
            cadenasValidas[i] = solicitarCadena();
            numerosValidos[i] = validarCadena (cadenasValidas[i]);
        }
        
       // Generar el array de booleanos correspondiente
       boolean[] empiezaConT = generarArrayBooleanos(cadenasValidas);
       
       // Mostrar por pantalla todos los valores de los dos arrays en formato tabulado
        System.out.println("Cadenas\t\tNúmeros Válidos");
        for(int i = 0; i< TAMANO_ARRAY; i++) {
            System.out.println(cadenasValidas[i] + "\t" + empiezaConT[i]);
        }
    }
    
    private static String solicitarCadena(){
        String inputCadena;
        do{
            System.out.println("Introduce 4 letras seguidas de un \"-\" y 3 números (formato LLLL-NNN)."); 
            inputCadena = scanner.nextLine();
            
            if (!validarCadena(inputCadena)) {
                System.out.println("Error: La cadena no cumple con el formato correcto.");
            }
        }while (!validarCadena(inputCadena));
        return inputCadena;
    }
    
    private static boolean validarCadena(String cadena){
        //Utilizar expresiones regulares para validar el formato
        return cadena.matches("[A-Za-z]{4}-\\d{3}");
    }
    
    private static boolean[] generarArrayBooleanos(String[] cadenas) {
        boolean[] result = new boolean[TAMANO_ARRAY];
        for(int i=0; i<TAMANO_ARRAY; i++) {
            result[i] = cadenas[i].startsWith("T");
        }
        return result;
    }   
}
