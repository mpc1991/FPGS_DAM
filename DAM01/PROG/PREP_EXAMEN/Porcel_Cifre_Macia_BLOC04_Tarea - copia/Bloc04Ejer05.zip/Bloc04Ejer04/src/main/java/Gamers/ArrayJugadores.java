/**
 * gestionar un array de objetos Jugador en el sistema Gamers.
 * Permite agregar nuevos jugadores, obtener jugadores por alias, contar jugadores con
 * una cantidad específica de munición, mostrar todos los jugadores, aumentar la munición
 * de un jugador y mostrar la factura de un jugador.
 * @author Macia Porcel
 */
package Gamers;

public class ArrayJugadores {
    private Jugador[] jugadores;
    private int numJugadores;
    private static final int maxJugadores = 40;

    // Constructor
    public ArrayJugadores(int maxJugadores) {
        jugadores = new Jugador[maxJugadores];
        numJugadores = 0;
    }

    // Método para agregar un nuevo jugador al array
    public boolean addJugador(String nombre, int municion) {
        // Crear una nueva instancia de Jugador con los datos proporcionados
        Jugador jugador = new Jugador(nombre, municion);

        // Verificar si hay espacio en el array
        if (numJugadores < jugadores.length) {
            jugadores[numJugadores] = jugador;
            numJugadores++;
            return true;
        } else {
            return false; // Array is full
        }
    }

    // Método para obtener un jugador por alias
    public Jugador getJugador(String alias) throws IllegalArgumentException {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getAlias().equals(alias)) {
                // Devolver una copia del jugador para preservar la integridad de los datos
                return new Jugador(jugadores[i].getNombre(), jugadores[i].getMunicion());

            }
        }
        throw new IllegalArgumentException("Player with alias " + alias + " not found.");
    }

    public int countPlayersWithMunicion(int municion) {
        int count = 0;
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getMunicion() == municion) {
                count++;
            }
        }
    return count;
    }
    
    public void displayAllJugadores() {
        for (int i = 0; i < numJugadores; i++) {
            System.out.println(jugadores[i].toString());
        }
    }
    public void increaseMunicion(String alias, int cantidad) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getAlias().equals(alias)) {
                jugadores[i].increaseMunicion(cantidad);
                return;
            }
        }
        // Si llegamos aquí, no se encontró ningún jugador con el alias proporcionado
        throw new IllegalArgumentException("Player with alias " + alias + " not found.");
    }
    
public void displayPlayerBill(String alias) {
    try {
        Jugador jugador = getJugador(alias);
        System.out.println("Factura del jugador " + alias + ":");
        mostrarDatosFactura(jugador);
    } catch (IllegalArgumentException e) {
        System.out.println(e.getMessage());
    }
}

    private void mostrarDatosFactura(Jugador jugador) {
        //costo diario y el total basado en los días alquilados.
        double costoDiario = jugador.costeDiario(); 
        int diasAlquilados = Utilidades.Utilidades.demanaSencer("Ingrese la cantidad de días para la factura:");

        // Puedes ajustar el formato según tus necesidades
        System.out.println("Nombre: " + jugador.getNombre());
        System.out.println("Alias: " + jugador.getAlias());
        System.out.println("Munición: "+ jugador.getMunicion());
        System.out.println("Costo diario: " + costoDiario);
        System.out.println("Días alquilados: " + diasAlquilados);
        System.out.println("Total: " + costoDiario * diasAlquilados);
    }
}
