package Gamers;

import java.time.LocalDate;

/**
 * Clase que representa a un jugador en el sistema Gamers
 * Cada jugador tiene un nombre, una cantidad de munición, un alias, una puntuación,
 * una fecha de alta y un identificador único
 * 
 * @author Macià Porcel Cifre
 */
public class Jugador{
    private String nombre;
    private Integer municion;
    private String alias;
    private int puntuacion;
    private LocalDate fechaAlta;
    private static int contadorJugadores = 1;
    
    // Constructor de la clase Jugador
    public Jugador (String nombre, int municion){
    
        //validamos los datos
        validarDatos(nombre, municion);
        
        // Asignamos valores a los atributos
        this.nombre = nombre; 
        this.municion = municion;
        this.alias = generarAlias();
        this.puntuacion = 0; // Inicializacion de la puntuacion en 0
        this.fechaAlta = LocalDate.now();
        contadorJugadores++;
    }
    
    // Método Getter para obtener el nombre del jugador
    public String getNombre() {
        return nombre;
    }
    
    // Método getter para obtener la munición del jugador
    public int getMunicion(){
        return municion;
    }
    
    // Método getter para obtener la fecha de alta del jugador
    public LocalDate getFechaAlta(){
        return fechaAlta;
    }
    
    public String getAlias() {
        return alias;
    }
    
    // Setter para la cantidad de municion
    public void setMunicion(int municion) {
        // Validamos la munición antes de asignarla
        validarDatos(this.nombre, municion);
        this.municion = municion;
    }
    
    // método toString sobrescrito para representar el objeto como cadena 
    @Override
    public String toString() {
        return "Jugador; " + nombre + ", Alias: " + alias + ", Puntuación: " + puntuacion + ", Munición: " + municion;
    }
    
    // Método privado para validar datos
    private void validarDatos (String nombre, int municion) {
        //Validamos el nombre
        if (nombre.length() < 5 || nombre.length() > 40) {
            throw new IllegalArgumentException("El nombre debe tener entre 5 y 40 caracteres.");
        }
        
        //Validamos la munición
        if (municion <= 0 || municion > 50) {
            throw new IllegalArgumentException("La munición debe ser un número entero entre 1 y 50.\nTu munición actual es: " + municion);
        }     
    }  
    
    // Método privado para generar el alias
    private String generarAlias(){
        // Generamos un alias utilizando los primeros 5 carácteres de nombre y el contador de jugadores
        return nombre.substring(0, Math.min(nombre.length(), 5)) + contadorJugadores;
    }
    
    // Método para aumentar la munición
    public void increaseMunicion(int cantidad) {
        // Validar la cantidad antes de aumentarla
        validarDatos(this.nombre, this.municion + cantidad);
        this.municion += cantidad;
    }
    public double costeDiario() {
    // Indicamos precio de la munición
    return 0.25 * this.municion;
    }
}
