
package Utilidades;
/**
 * Clase de utilidades para la gestión de entrada de datos
 * Proporciona métodos estáticos para leer datos de entrada
 * 
 * @author Macià Porcel Cifre
 */
import java.util.Scanner;

public class Utilidades {
    // Instancia única del scanner para entrada de datos
    private static Scanner scanner = new Scanner(System.in);

    /**
    * Método estático para solicitar y leer un número entero desde la consola.
    *
    * @param mensaje Mensaje que se muestra al solicitar el número.
    * @return Entero ingresado por el usuario o null si la entrada no es válida.
    */
    public static Integer demanaSencer(String mensaje) {
        try {
            // Solicita al usuario que ingrese un número entero
            System.out.print(mensaje+"\n");
            String input = scanner.next();
            int result = Integer.parseInt(input);
            scanner.nextLine(); // Limpia el buffer del scanner            
            return result;
        } catch (ArithmeticException | NullPointerException | NumberFormatException e) {
            // En caso de error, devuelve null y maneja la excepción
            // Usamos Integer en vez de int para manejar excepciones null
            Integer noValidNum = null;
            return noValidNum;
        } 
    }

    // Método estático para solicitar y leer una cadena desde la consola
    public static String demanaCadena(String mensaje) {
        // Solicita al usuario que ingrese una cadena
        System.out.print(mensaje+"\n");
        return scanner.nextLine();
    }
    
    /**
     * Método estático para solicitar y leer un valor booleano desde la consola.
     * Acepta entradas como "si", "no", "yes", "no", "true" y "false" (sin distinción de mayúsculas).
     *
    * @param mensaje Mensaje que se muestra al solicitar el valor booleano.
    * @return Valor booleano ingresado por el usuario o null si la entrada no es válida.
    */
    public static boolean demanaBoolean(String mensaje) {
        // Solicita al usuario que ingrese una valor Booleano
        // Usamos Boolean en vez de boolean para poder manejar expeciones null
        System.out.print(mensaje+"\n");
        String input = scanner.next().toLowerCase();
        // Comprueba las distintas formas de entrada válidas y retorna el valor Booleano correspondiente
        if (input.equals("si") ||input.equals("yes")||input.equals("true")) {
            return true;
        } else if (input.equals("no") || input.equals("false")){
            return false;
        } else {
            // En caso de entrada no válida, devuelve null
            Boolean niSiniNo = null;
        return niSiniNo;
        }
    }

    /**
    * Método estático para solicitar y leer una cadena que representa una fecha desde la consola.
    *
    * @param mensaje Mensaje que se muestra al solicitar la fecha.
    * @return Cadena que representa una fecha ingresada por el usuario.
    */
    public static String demanaData(String mensaje) {
        try {
            // Solicita al usuario que ingrese una cadena que represente una fecha
            System.out.print(mensaje+"\n");
            return scanner.next();
        } catch (NullPointerException e) {
            // En caso de excepción, devuelve una cadena vacía
            return "";
        }
    }
}

