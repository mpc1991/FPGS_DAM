package com.mycompany.bloc04ejer03;

/**
 * Este código Java se encarga de realizar operaciones con matrices bidimensionales. 
 * En primer lugar, solicita al usuario que introduzca valores para llenar una matriz de tamaño 3x4. Luego, calcula y almacena los valores mínimos de 
 * cada columna en un array. Finalmente, muestra la matriz original y el array de valores mínimos por columna en formato tabulado.
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;

public class Bloc04Ejer03 {
    
    public static void main(String[] args) {
        double [][] matriz= new double[3][4];
        
        //Pedir valores para la matriz
        pedirValoresMatriz(matriz);
        
        // Calcular el array con los valores mínimos de cada columna
        double[] valoresMinimos = calcularValoresMinimos(matriz);
        
        // Mostrar la matriz
        System.out.println("Matriz:");
        mostrarMatriz(matriz);
        
        // Mostrar el array de valores mínimos
        System.out.println("\nValores Mínimos por Columna:");
        mostrarArray(valoresMinimos);
    }
    
    // Método para pedir valores para la matriz
    public static void pedirValoresMatriz(double[][] matriz) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Introduce los valores para la matriz (3x4): ");
        
        for (int i = 0; i<matriz.length;i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                boolean inputValido = false;
                
                while (!inputValido) {
                    try{ 
                    System.out.print("Matriz[" + i + "][" + j + "]: ");
                    matriz[i][j] = scanner.nextDouble();
                    inputValido = true;
                    } catch (Exception e){
                        System.out.println("Error: Los datos introducidos deben ser números.");
                        scanner.next(); // Limpiar el buffer del scanner
                    }
                }
            }
        }
    }
    
    // Método para calcular valores mínimos de cada columna y almacenarlos en un array
    public static double[] calcularValoresMinimos(double[][] matriz) {
        double[] valoresMinimos = new double[matriz[0].length];

        for (int j = 0; j < matriz[0].length; j++) {
            double minimo = matriz[0][j];
            for (int i = 1; i < matriz.length; i++) {
                if (matriz[i][j] < minimo) {
                    minimo = matriz[i][j];
                }
            }
            valoresMinimos[j] = minimo;
        }

        return valoresMinimos;
    }
    
    // Método para mostrar la matriz por pantalla
    public static void mostrarMatriz(double[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }

    // Método para mostrar un array por pantalla
    public static void mostrarArray(double[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println("Columna[" + i + "]: " + array[i]);
        }
    }
}
