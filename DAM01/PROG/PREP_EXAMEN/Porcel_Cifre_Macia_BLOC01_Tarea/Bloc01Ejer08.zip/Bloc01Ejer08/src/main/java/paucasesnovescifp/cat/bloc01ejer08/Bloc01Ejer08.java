/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer08;

/**
 *
 * @author seek_
 */
import java.util.Scanner;
public class Bloc01Ejer08 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        System.out.print("Segundos a convertir: ");
        int segundosImputados = teclado.nextInt();
        
        int segundos = segundosImputados % 60;
        int minutos = (segundosImputados / 60) % 60;
        int horas = (segundosImputados / 3600) % 24;
        int dias = (segundosImputados / 86400);
        
        System.out.println("Dias: " + dias);
        System.out.println("Horas: " + horas);
        System.out.println("Minutos: " + minutos);
        System.out.println("Segundos: " + segundos);        
    }
}
