/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer05;

/**
 *
 * @author seek_
 */
public class Bloc01Ejer05 {

    public static void main(String[] args) {
        
        // Declaramos e inicialización de las variables
        short shortBits = 16;
        int intBits = 32;
        long longBits = 64;
        double doubleBits = 64.000000000000000;
        boolean booleanVariable = false;
        
        System.out.println("Los bits de los siguientes datos son;\nshort: " + shortBits + "\nint: " + intBits + "\nlong: " + longBits + "\nfloat: " + doubleBits  + "\n\nNos acordamos ya de todos?: " + booleanVariable);
    }
}
