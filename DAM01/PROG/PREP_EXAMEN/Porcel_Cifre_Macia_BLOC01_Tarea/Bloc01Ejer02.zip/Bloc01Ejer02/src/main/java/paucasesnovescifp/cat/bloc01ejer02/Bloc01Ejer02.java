/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer02;

/**
 *
 * @author seek_
 */
public class Bloc01Ejer02 {

    public static void main(String[] args) {
    String nombre = "Macià ";
    String primerApellido = "Porcel ";
    String segundoApellido ="Cifre ";
    String nombreCompleto = nombre + primerApellido + segundoApellido;
    int edad = 32;
    System.out.println("Nombre: " + nombre);
    System.out.println("Apellidos: " + primerApellido + segundoApellido);
    System.out.println("Nombre completo: " + nombreCompleto);  
    System.out.println("Edad: " + edad);
  }
}
