/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer01;

/**
 *
 * @author seek_
 */
public class Bloc01Ejer01 {    
  public static void main(String[] args) {
    String name = "Macià Porcel";
    System.out.println(name);
  }
}
