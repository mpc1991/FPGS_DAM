/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer07;

/**
 *
 * @author seek_
 */
import java.util.Scanner; // Importamos la clase Scanner
public class Bloc01Ejer07 {

    public static void main(String[] args) {
        //clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);
        
        //Solicitamos la temperatura Kelvin
        System.out.print("Introduce grados Kelvin: ");
        double kelvin = teclado.nextDouble();
        
        //Convesión
        double celsius = kelvin - 273.15;
        
        //resultado
        System.out.println(celsius);
        
        
    }
}
