/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer09;

/**
 *
 * @author seek_
 */
import java.util.Scanner;
public class Bloc01Ejer09 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in); 
  
        //Precio billete autobús.real
        System.out.print("Precio billete: ");
        Double precioBillete = teclado.nextDouble();  

        //Número pasajeros.entero
        System.out.print("Total pasajeros: ");
        int numPasajeros = teclado.nextInt();

        //Cuantos menores de edad.entero 40%desc
        System.out.print("Cuantos niños: ");
        int menoresEdad = teclado.nextInt();

        //Total recaudado solo adultos
        Double importeAdultos = (numPasajeros - menoresEdad) * precioBillete; 
        System.out.println("Recaudado adultos: " + importeAdultos + "€");

        //Total recaudado solo menores
        Double importeMenores = (menoresEdad * precioBillete)*0.4;
        System.out.println("Recaudado menores: " + importeMenores + "€");

        //Total recaudado
        Double totalRecaudado = (importeAdultos + importeMenores);
        System.out.println("Total recaudado: " + totalRecaudado + "€");  
    }
}

