/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer06;

/**
 *
 * @author seek_
 */
import java.util.Scanner; // Importamos la clase Scanner
public class Bloc01Ejer06 {

    public static void main(String[] strings) {
        //clase Scanner para petición de datos
        Scanner teclado = new Scanner ( System.in );
        double ancho = 0;
        double alto = 0;
        
        // Define constants for the width and height of the rectangle
        System.out.print ("Introduce el ancho: ");
        ancho = teclado.nextDouble(); //pedimos el ancho al usuario
        
        System.out.print ("Introduce la altura: ");
        alto = teclado.nextDouble(); //pedimos la altura al usuario

        // Calculate the perimeter of the rectangle
        double perimeter = 2 * (alto + ancho);
		
        // Calculate the area of the rectangle
        double area = ancho * alto;			

        // Print the calculated perimeter using placeholders for values
        System.out.printf("Perimeter is 2*(%.1f + %.1f) = %.2f \n", alto, ancho, perimeter);

        // Print the calculated area using placeholders for values
        System.out.printf("Area is %.1f * %.1f = %.2f \n", alto, ancho, area);
    }
}