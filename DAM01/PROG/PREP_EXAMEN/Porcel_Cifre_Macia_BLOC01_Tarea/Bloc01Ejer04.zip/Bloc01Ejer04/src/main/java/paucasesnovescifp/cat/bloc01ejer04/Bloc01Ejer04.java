/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package paucasesnovescifp.cat.bloc01ejer04;

/**
 *
 * @author seek_
 */
public class Bloc01Ejer04 {

    public static void main(String[] args) {
        
        final short valor = 25; // Utilizamos final para indicar que es constante y short para representar el valor entero más ajustado.
        String estacion = "primavera"; // Utilizamos String para almacenar texto.
        char letraNIF = 'R'; // Utilizamos char para representar un único carácter.
        float salario = 3600.99f; // Utilizamos double en vez de float para no perder precisión en los cálculos.

        System.out.println("Valor: " + valor + "\nEstació: " + estacion + "\nLetra del NIF: " + letraNIF + "\nSalario: " + salario + "€");
    }
}
