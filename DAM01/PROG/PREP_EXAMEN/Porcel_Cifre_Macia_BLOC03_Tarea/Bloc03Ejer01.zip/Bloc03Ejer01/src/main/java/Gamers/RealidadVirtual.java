
package Gamers;

/**
 * Clase que representa un entorno de Realidad Virtual en el sistema Gamers
 * Cada entorno tiene un númeri de objetos virtuales, calidad de gráficos, intensidad de experiencia
 * y una indicación de si tiene audio o no
 * 
 * @author Macià Porcel Cifre
 */

public class RealidadVirtual {
    private int objetosVirtuales;
    private int calidadGraficos;
    private int intensidadExperiencia;
    private boolean tieneAudio;

    // Constructor de la clase RealidadVirtual
    public RealidadVirtual(int objetosVirtuales, int calidadGraficos, int intensidadExperiencia, boolean tieneAudio) {
        // Validamos los datos
        validarDatos(objetosVirtuales,calidadGraficos, intensidadExperiencia);

        // Asignamos valores a los atributos
        this.objetosVirtuales = objetosVirtuales;
        this.calidadGraficos = calidadGraficos;
        this.intensidadExperiencia = intensidadExperiencia;
        this.tieneAudio = tieneAudio;
    }

    // Setters para la cantidad de objetos virtuales del entorno
    public void setObjetosVirtuales(int objetosVirtuales) {
        try {
            // Validamos los datos antes de asignar el número de objetos virtuales
            validarDatos(objetosVirtuales,this.calidadGraficos, this.intensidadExperiencia);
            this.objetosVirtuales = objetosVirtuales;
        } catch (IllegalArgumentException e) {
            // Manejamos excepciones en caso de datos no válidos
            System.out.println("Error al establecer el número de objetos virtuales: " + e.getMessage());
        }
    }
    
    // Método getter para obtener la cantidad de objetos virtuales del entorno de Realidad Virtual
    public int getObjetosVirtuales() {
        return objetosVirtuales;
    }
    
    // Método getter para obtener si el entorno tiene audio o no
    public Boolean getTieneAudio(){
        return tieneAudio;
    }
        
    // Método toString sobrescrito para representar el objeto como cadena
    @Override
    public String toString() {
        // Variable para almacenar la representación de la presencia de audio
        String TieneAudio=null;
        if (tieneAudio == true) { TieneAudio = ("Si");}
        if (tieneAudio == false) {TieneAudio =("No");}
        
        // Construir y retornar la cadena de representación del objeto
        return "Realidad Virtual: \n- Objetos Virtuales: " + objetosVirtuales
             + "\n- Calidad de Gráficos: " + calidadGraficos
             + "\n- Intensidad de Experiencia: " + intensidadExperiencia
             + "\n- Tiene Audio: " + TieneAudio;
    }

    // Método para validar datos
    private void validarDatos(int objetosVirtuales,int calidadGraficos, int intensidadExperiencia) {
        // Validamos el número de objetos virtuales
        if (objetosVirtuales <= 0) {
            throw new IllegalArgumentException("El número de objetos virtuales debe ser un número entero positivo (1 o +).");
        }
        
        // Validamos la calidad gráfica
        if (calidadGraficos < 0 || calidadGraficos > 100) {
            throw new IllegalArgumentException("La calidad gráfica sólo puede medirse de 0 a 100");
        }

        // Validamos la intensidad de la experiencia
        if (intensidadExperiencia < 0 || intensidadExperiencia > 100) {
            throw new IllegalArgumentException("La intensidad de la experiencia debe estar entre 0 y 100.");
        }
    }

    // Método para calcular el costo diario
    public double costeDiario() {
        // Calcula el costo según las especificaciones dadas
        double coste = 0.25 * objetosVirtuales;
        
        // Añade el costo por audio si el entorno tiene audio
        if (tieneAudio) {
            coste += 1.0;
        }
        
        // Devuelve el costo diario calculado
        return coste;
    }

    // Método para calcular el costo total
    public double totalCoste(int dias) {
        // Calcula el costo total para un número de días multiplicando el costo diario por los días
        return dias * costeDiario();
    }
}
