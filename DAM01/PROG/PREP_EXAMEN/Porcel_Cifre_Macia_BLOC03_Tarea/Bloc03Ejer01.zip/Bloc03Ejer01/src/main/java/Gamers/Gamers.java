package Gamers;

/**
 * Aplicación Java denominada Gamers que permita gestionar la facturación a un jugador en 
 * un juego de realidad virtual.  
 * Mediante un menú que aparecerá en pantalla se podrán realizar determinadas operaciones 
 * @author Macià Porcel Cifre
 */

import java.util.InputMismatchException;
import Utilidades.Utilidades;
import java.time.LocalDate;
import java.lang.NullPointerException;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;


public class Gamers {
    private static Jugador jugador;  // Declaramos un objeto Jugador
    private static RealidadVirtual realidadVirtual;  // Declaramos un objeto RealidadVirtual

    public static void main(String[] args) {
        int opcion=0;
        
        do {
            try {
                mostrarMenu(); // Llamamos al método que muestra el menú
                opcion = Utilidades.demanaSencer("Bienvenido a Gamers!\nPor favor, elige una opción: ");
            
                // Switch para manejar las opciones del menú.
                switch (opcion) {
                    case 1:
                        crearJugador(); // Llamamos al método para crear un jugador
                        break;
                    case 2:
                        verDatosJugador(); // Llamamos al método para ver datos del jugador
                        break;
                    case 3:
                        aumentarMunicion(); // Llamamos al método para aumentar la munición del jugador
                        break;
                    case 4:
                        crearRealidadVirtual(); // Llamamos al método para crear una realidad virtual
                        break;
                    case 5:
                        verDatosRealidadVirtual(); // Llamamos al método para ver datos de la realidad virtual
                        break;
                    case 6:
                        modificarObjetosVirtuales(); // Llamamos al método para modificar objetos virtuales 
                        break;
                    case 7:
                    generarFactura(); // Llamamos al método para generar una factura
                    break;
                    case 8:
                        System.out.println("¡Hasta luego!"); // Mensaje de despedida
                        break;
                    default:
                        System.out.println("Opción no válida. Inténtalo de nuevo."); // Mensaje en caso de opción no válida
                }
            } catch (Exception e) { // capturamos la excepciones de decimales y tipo de dato incorrecto
                System.out.println("Opción no válida. Inténtalo de nuevo");
            }
        } while (opcion != 8); // Salimos del bucle cuando la opción es 8

    }
    // Método para mistrar el menú de opciones
    private static void mostrarMenu() {
        System.out.println("Menu:");
        System.out.println("1. Crear jugador");
        System.out.println("2. Ver datos del jugador");
        System.out.println("3. Aumentar la munición del jugador");
        System.out.println("4. Crear una realidad virtual");
        System.out.println("5. Ver datos de la realidad virtual");
        System.out.println("6. Modificar el número de objetos virtuales");
        System.out.println("7. Mostrar la factura del jugador");
        System.out.println("8. Salir");
    }

private static void crearJugador() {
    // Declaracion de variables locales
    String nombre;
    Integer municion;
    
    try {
        // Solicitamos el nombre del jugador
        nombre = Utilidades.demanaCadena("Introduce el nombre del jugador (min 5-40 max caracteres): ");
        
        // Solicitamos municion
        municion = Utilidades.demanaSencer("Introduce la cantidad de munición (num entero, min 1-50 max): ");
        
        // Verificamos si la munición es válida
        if (municion != null || municion <= 0 || municion >50){
            // Creamos un nuevo objeto Jugador con el nombre y la munición proporcionadas
            jugador = new Jugador(nombre, municion);
            
            // Mostramos mensaje de éxito en la creación
            System.out.println("¡Jugador creado exitosamente!\n" + jugador.toString());
        } else {
            // Mostramos mensaje de error si la munición no es válida
            System.out.println("La munición debe ser un número entero entre 1 y 50.\nTu munición actual es: " + municion);
        }
        
        // Manejamos las diferentes excepciones
    } catch (InputMismatchException e) {
        System.out.println("Error: Entrada no válida. Por favor, inténtalo de nuevo.");
        Utilidades.demanaSencer("");  // Limpiar el buffer del scanner
    } catch (IllegalArgumentException e) {
        System.out.println("Error al crear el jugador: " + e.getMessage());
    } catch (NullPointerException e) {
        System.out.println("Error al crear el jugador: La munición debe ser un número entero entre 1 y 50.");
    }
}


    private static void verDatosJugador() {
        // Verificamos si existe un jugador creado
        if (jugador != null) {
            // Mostramos los datos del jugador usando toString()
            System.out.println(jugador.toString());
        } else {
            // Mostramos mensaje si no se ha creado el jugador
            System.out.println("Aún no se ha creado ningún jugador.");
        }
    }

    private static void aumentarMunicion() {
        // Verificamos si existe un jugador creado
        if (jugador != null){
            try {
                // Solicitamos al usuario que ingrese la cantidad de munición a aumentar
                int cantidad = Utilidades.demanaSencer("Introduce la cantidad a aumentar: ");
            
                // Verificamos si la cantidad de munición ingresada es válida
                if (cantidad <= 0) {
                    System.out.println("Error: Se deben introducir número enteros positivos.");
                    return;
                }
                
                // Aumentamos la munición del jugador según la cantidad ingresada
                jugador.setMunicion(jugador.getMunicion() + cantidad);
                
                // Mostramos mensaje de éxito junto con la munición actualizada del jugador
                System.out.println("Munición aumentada exitosamente. Munición actual: " + jugador.getMunicion());
            
            // Manejamos las posibles excepciones
            } catch (IllegalArgumentException e) {
                int municionPermitida = 50 - jugador.getMunicion();
            
                System.out.println("Se ha superado el máximo de munición permitida (max = 50).");
                System.out.println("Sólo puedes añadir " + municionPermitida + " de munición adicional.");
            } catch (NullPointerException e) {
                System.out.println("Error: Se deben introducir número enteros positivos.");
            }
        } else {
            // Mostramos un mensaje si no se ha creado ningún jugador
            System.out.println("Aún no se ha creado ningún jugador.");
        }
    }
    
    private static void crearRealidadVirtual() {
        // Verificamos si existe un jugador creado
        if (jugador != null){ 
            // Solicitamos al usuario la cantidad de objetos virtuales a crear
            int objetosVirtuales = Utilidades.demanaSencer("Introduce la cantidad de objetos virtuales: ");
            
            // Solicitamos al usuario la cantidad de gráficos
            // Se usa Integer en vez de int para manejar excepciones null
            Integer calidadGraficos = Utilidades.demanaSencer("Introduce la calidad de gráficos (0-100): ");
            
            // Verificamos si la cantidad de gráficos es válida
            if (calidadGraficos != null) {
                
                // Solicitamos al usuario la calidad de la experiencia
                // Se usa Integer en vez de int para manejar excepciones null
                Integer intensidadExperiencia = Utilidades.demanaSencer("Introduce la intensidad de la experiencia (0-100): ");
                
                // Verificamos si la intensidad de la experiencia es válida
                if (intensidadExperiencia != null) {
                    try {
                        // Solicitamos al usuario si quiere audio o no
                        // Usamos Boolean en vez de boolean para manejar excepciones null
                        Boolean tieneAudio = Utilidades.demanaBoolean("¿Tiene audio? (Si/No): ");
                        
                        try {
                            // Creamos un nuevo objeto Realidad Virtual con la información proporcionada
                            realidadVirtual = new RealidadVirtual(objetosVirtuales, calidadGraficos, intensidadExperiencia, tieneAudio);
                            
                            // Mostramos mensaje de éxito en la creación de la realidad virtual
                            System.out.println("¡Realidad Virtual creada exitosamente!");
                        // Manejamos excepción IllegalArgument
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error al crear la Realidad Virtual: " + e.getMessage());
                        }
                    // Manejamos excepción NullPointer
                    } catch (NullPointerException e){
                        System.out.println("Error: Entrada de audio no válida. Por favor, elija Si o No.");
                    }
                } else {
                    // Mostramos mensaje de error si la intensidad de la experiencia no es válida
                    System.out.println("Error: La intensidad de la expericencia debe ser un número entero entre 0 y 100."); 
                }
            } else{
                // Mostramos mensaje de error si la calidad gráfica no es válida  
                System.out.println("Error: La calidad gráfica sólo puede medirse de 0 a 100.");
            }
        } else {
            // Mostramos mensaje de error si todavía no se ha creado un jugador
            System.out.println("Aún no se ha creado ningún jugador.");
        }
    }

    private static void verDatosRealidadVirtual() {
        // Verificamos si existe una instancia de Realidad virtual creada
        if (realidadVirtual != null) {
            // Mostramos los datos de la Realidad Virtual utilizando el método toString()
            System.out.println(realidadVirtual.toString());
            
            // Mostramos el coste diario de la realidad virtual en €
            System.out.println("Coste diario: " + String.format("%.2f€", realidadVirtual.costeDiario()));
        } else {
            // Mostramos mensaje de error si no se ha creado ninguna realidad virtual
            System.out.println("Aún no se ha creado ninguna Realidad Virtual.");
        }
    }

    private static void modificarObjetosVirtuales() {
        // Verificamos si existe una realidad virtual creada
        if (realidadVirtual != null) {
            try {
                // Solicitamos al usuario el nuevo número de objetos virtuales
                int nuevosObjetosVirtuales = Utilidades.demanaSencer("Objetos viertuales actuales: " + realidadVirtual.getObjetosVirtuales() + "\nIntroduce el nuevo número de objetos virtuales: ");
                
                // Verificamos si el nuevo número de objetos virtuales es válido
                if (nuevosObjetosVirtuales > 0){
                    // Modificamos el número de objetos virtuales
                    realidadVirtual.setObjetosVirtuales(nuevosObjetosVirtuales);
                    
                    // Mostramos mensaje de éxitojunto con la cantidad actualizada de objetos virtuales
                    System.out.println("Número de objetos virtuales modificado exitosamente.\nCantidad de objetos virtuales actual: "+nuevosObjetosVirtuales);
                } else {
                // Mostramos mensaje de error si el nuevo número de objetos virtuales no es válido
                System.out.println("Error: El número de objetos virtuales debe ser un número entero positivo (1 o +).");
                }
            } catch (NullPointerException e) {
                // Capturamos excepción NullPointer
                System.out.println("Error: El número de objetos virtuales debe ser un número entero positivo (1 o +).");
            }
        } else {
            // Mostramos mensaje si no se ha creado ninguna Realidad virtual
            System.out.println("Aún no se ha creado ninguna Realidad Virtual.");
        }
    }

    /**
    * Imprime una línea formateada en la consola con dos columnas.
    * Lo usamos para imprimir la factura de una forma más visual
    * @param left  Texto para la columna izquierda.
    * @param right Texto para la columna derecha.
    */ 
    private static void printLine(String left, String right) {
        // Utiliza printf para formatear e imprimir la línea con los textos proporcionados en las columnas
        System.out.printf("| %-50s | %-32s |\n", left, right);
    }

 
    private static void generarFactura() {
        // Verificamos que exista un jugador y una realidad virtual creadas
        if (jugador != null && realidadVirtual != null) {
            try {
                // Solicitamos al usuario la fecha de facturación en formato "yyyy-MM-dd"
                String fechaFacturacion = Utilidades.demanaData("Introduce la fecha de facturación (yyyy-MM-dd): ");
                
                // Convertimos la fecha de facturación a un objeto LocalDate
                LocalDate fechaFactura = LocalDate.parse(fechaFacturacion);
                
                // Calculamos los días facturados desde la fecha de alta del jugador hasta la fecha de facturación
                long diasFacturados = Math.abs(jugador.getFechaAlta().toEpochDay() - fechaFactura.toEpochDay());
                
                // Verificamos si la fecha de facturación es valida (posterior o igual a la fecha de alta del jugador)
                if (!fechaFactura.isBefore(jugador.getFechaAlta()) || fechaFacturacion != null){
                    
                    // Calculamos el costo de los objetos virtuales a partir de la cantidad sin sumar el audio
                    Double costeObjetos = (realidadVirtual.getObjetosVirtuales() * 0.25);
                    String CosteObjetos = Double.toString(costeObjetos);
                    
                    // Calcular el costo total de la Realidad Virtual para los días facturados
                    double totalFacturado = realidadVirtual.totalCoste((int) diasFacturados);

                    // Mostrar la factura
                    System.out.println();
                    System.out.println("-----------------------------------------------------------------------------------------");
                    System.out.println("|                                     Factura                                           |");
                    System.out.println("-----------------------------------------------------------------------------------------");

                    // Imprimimos detalles de la factura
                    printLine("Emisor de la factura", "");
                    printLine("   - Nombre", "Macià");
                    printLine("   - Apellidos", "Porcel Cifre");
                    printLine("   - Correo corporativo", "maciaporcel@cifpaucasesnoves.com");
                    printLine("   - Nombre del proyecto", "Gamers");
            
                    System.out.println("-----------------------------------------------------------------------------------------");
            
                    System.out.println("| Datos de facturación:                                                                 |");
                    printLine("   - Fecha facturación: " , fechaFacturacion);
                    System.out.println("|                                                                                       |");
                    System.out.println("| Destinatario de la factura:                                                           |");
                    printLine("   - Jugador", jugador.getNombre());

                    System.out.println("-----------------------------------------------------------------------------------------");
            
                    System.out.println("| Detalles de la factura:                                                               |");
                    printLine("Precio por día - Ojetos: " + realidadVirtual.getObjetosVirtuales(), CosteObjetos + ("€"));

                    printLine("Precio por día - Audio", realidadVirtual.getTieneAudio() ? "1€" : "0€");
                    printLine("Total por día - Realidad Virtual",String.format("%.2f€", realidadVirtual.costeDiario()));
                    System.out.println("|                                                                                       |");
                    printLine("Días entre fecha de alta y fecha facturación", String.valueOf(diasFacturados));
                    printLine("Total facturado sin IVA", String.format("%.2f€", totalFacturado));
                    
                    // Calcular y mostrar el 21% de IVA a aplicar
                    double iva = totalFacturado * 0.21;
                    printLine("21% de IVA a aplicar", String.format("%.2f€", iva));

                    // Calcular y mostrar el total a pagar por el jugador
                    double totalPagar = totalFacturado + iva;
                    System.out.println("-----------------------------------------------------------------------------------------");

                    printLine("   - TOTAL", String.format("%.2f€", totalPagar));
                    System.out.println("-----------------------------------------------------------------------------------------\n\n");
                } else{
                    // Mostrar mensaje de error si la fecha de facturación no es válida
                    System.out.println("La fecha de facturación debe ser posterior a la fecha de creación del entorno");
                }
            } catch (DateTimeParseException | NullPointerException e) {
                // Manejamos excepciones de tipo DateTimeParse y NullPointer
                System.out.println("El formato debe de ser YYYY-MM-DD, ejemplo: 2024-03-01");
            } catch (Exception e) {
                // Manejamos otras excepciones no previstas
                System.out.println("El formato debe de ser YYYY-MM-DD, ejemplo: 2024-03-01");
            }
        } else {
            // Mostramos mensaje si no se han creado un jugador o una realidad virtual
            System.out.println("Aún no se han creado un jugador o una Realidad Virtual.");
        }
    }
}
    

