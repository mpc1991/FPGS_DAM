package empresa_porcel;
/**
 * Esta clase representa un departamento dentro de una empresa.
 * Contiene información sobre el nombre, ubicación y sueldo base del departamento.
 * @author Macia Porcel Cifre
 */
public class Departamento {
    
    private String nombre;
    private String ubicacion;
    private double sueldoBase;
    
    // Constructor de la clase Departamento
    public Departamento (String nombre, String ubicacion){
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.sueldoBase = sueldoBase;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the ubicacion
     */
    public String getUbicacion() {
        return ubicacion;
    }

    /**
     * @param ubicacion the ubicacion to set
     */
    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    /**
     * @return the sueldoBase
     */
    public double getSueldoBase() {
        return sueldoBase;
    }

    /**
     * @param sueldoBase the sueldoBase to set
     */
    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
}
