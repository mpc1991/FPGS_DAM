/*
 * Programa para gestionar los recursos humanos de una empresa.
 * Permite añadir trabajadores, establecer sueldo base máximo,
 * mostrar datos de trabajadores, modificar horas extra,
 * mostrar nómina y calcular total de nóminas por departamento.
 */

package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */
import java.util.Scanner;
public class Empresa_Porcel {
    static Scanner in = new Scanner (System.in);
    static double sueldoBaseMaximo;
    static ArrayTrabajadores arrayTrabajadores = new ArrayTrabajadores();

    public static void main(String[] args) {
        int opcion=0;
        do{
            try {
            opcion = menu(); // Muestra el menú y obtiene la opción del usuario
            } catch (Exception e) {
                System.out.println("Debe ser un número entero del 1 al 7");
                in.nextLine(); // Consumir la entrada no válida
                continue; // Volver al principio del bucle
            }
            switch (opcion){
                case 1:
                    establecerSueldoBaseMaximo();
                    break;
                case 2:
                    addTrabajador();
                    break;
                case 3:
                    mostrarDatosTrabajadores();;
                    break;
                case 4:
                    modificarHorasExtra();
                    break;
                case 5:
                    mostrarNomina();
                    break;
                case 6:
                    mostrarTotalDepartamento();
                    break;
                case 7:
                    System.out.println("Saliendo del programa...");
                    break;
                default: 
                    System.out.println("Esta opcion no es correcta");
                    break;
            }
        }while (opcion != 7);
    }
    
    // Método para establecer el sueldo base máximo de la empresa
    private static void establecerSueldoBaseMaximo(){
        System.out.println("Introduzca el nuevo sueldo base máximo: ");
        try{
            sueldoBaseMaximo = in.nextDouble();
            System.out.println("Sueldo máximo actualizado.");
        } catch (Exception e) {
            System.out.println("Error: debe introducir un número decimal válido");
            in.nextLine();
        }
    }
    
    // Método para añadir un nuevo trabajador a la empresa
    private static void addTrabajador(){
        System.out.println("ingrese el nombre del trabajador");
        String nombre = in.nextLine();
        
        System.out.println("Ingrese el correo electrónico del trabajador");
        String mail = in.nextLine();
        
        System.out.println("Ingrese el teléfono del trabajador");
        String telefono =in.nextLine();
        
        System.out.println("Ingrese el nombre del departamento:");
        String nombreDepartamento = in.nextLine();
    
        System.out.println("Ingrese la ubicación del departamento:");
        String ubicacionDepartamento = in.nextLine();
    
        Departamento departamento = new Departamento(nombreDepartamento, ubicacionDepartamento);
    
        System.out.println("Ingrese el tipo de trabajador");
        System.out.println("1. Programador");
        System.out.println("2. Gestor");
        System.out.println("3. Director");
        try {
        int tipoTrabajador = in.nextInt();
        in.nextLine();
        
        Trabajador nuevoTrabajador = null;
            switch (tipoTrabajador) {
                case 1:
                    System.out.println("Ingrese el lenguaje de programacion: ");
                    String lenguaje = in.nextLine();
                    nuevoTrabajador = new Programador (nombre, mail, telefono, departamento, "", 0, lenguaje);
                    break;
                case 2:
                    System.out.println("Ingrese la especialidad: ");
                    String especialidad = in.nextLine();
                    nuevoTrabajador = new Gestor (nombre, mail, telefono, departamento, "", 0, especialidad);
                    break;
                case 3:
                    System.out.println("Ingrese la antiguedad: ");
                    try {
                        int antiguedad = in.nextInt();
                        in.nextLine();
                        nuevoTrabajador = new Director (nombre, mail, telefono, departamento, "", 0, antiguedad);
                        break;
                    }catch (Exception e) {
                        System.out.println("La antiguedad debe ser un número entero");
                        in.nextLine();
                    }
                default:
                    System.out.print("Tipo de trabajador no válido");
                    return;
            }

            // Agregar el nuevo trabajador al array de trabajadores
            boolean agregado = arrayTrabajadores.addTrabajador(nuevoTrabajador);
            if (agregado) {
                System.out.println("Trabajador agregado correctamente");
            } else {
                System.out.println("No se pudo agregar el trabajador, Se ha alcanzado el límite de trabajadores.");
            }
        } catch (Exception e){
        System.out.println("Debe seleccionar el tipo de trabajador introduciendo el número correspondiente");
        }
    }
    
    // Método para mostrar los datos de todos los trabajadores de la empresa
    private static void mostrarDatosTrabajadores() {
        Trabajador [] trabajadores = arrayTrabajadores.getTrabajadores();
        
        if (trabajadores.length == 0) {
            System.out.println("No hay trabajadores registrados.");
            return;
        }
        
        System.out.println("\n--------------------------------\n");
        System.out.println("Datos de todos los trabajadores:");
        for (Trabajador trabajador : trabajadores) {
            System.out.println("Nombre: " + trabajador.getNombre());
            System.out.println("Correo electrónico: " + trabajador.getMail());
            System.out.println("Teléfono: "+ trabajador.getTelefono());
            System.out.println("Departamento: " + trabajador.getDepartamento().getNombre());
            System.out.println("Identificador: " + trabajador.getIdentificador());
            System.out.println("Horas extra acumuladas: " + trabajador.getHorasExtra());
            System.out.println();
            
            // Verificar el tipo de trabajador y mostrar información adicional según el tipo
            if (trabajador instanceof Programador) {
            Programador programador = (Programador) trabajador;
            System.out.println("Lenguaje de programación: " + programador.getLenguaje());
            } else if (trabajador instanceof Gestor) {
            Gestor gestor = (Gestor) trabajador;
            System.out.println("Especialidad: " + gestor.getEspecialidad());
            } else if (trabajador instanceof Director) {
            Director director = (Director) trabajador;
            System.out.println("Antigüedad: " + director.getAntiguedad() + " años");
            }
            System.out.println("\n---------------------------------");
            System.out.println(); 
        }
    }
    
    // Método para modificar el número de horas extra de un trabajador
    private static void modificarHorasExtra() {
        System.out.println("Ingrese el identificador del trabajador para modificarle las horas extra: ");
        String identificador = in.nextLine();
        in.nextLine();
        
        try{
            Trabajador trabajador = arrayTrabajadores.getTrabajador(identificador);
            
            System.out.println("Ingrese el nuevo número de horas extra: ");
            int nuevasHorasExtra = in.nextInt();
            in.nextLine();
            
            trabajador.setHorasExtra(nuevasHorasExtra);
            System.out.println("Horas extra modificadas correctamente para el trabajador " + identificador);
        } catch (Exception e) {
            System.out.println("Error: No se encontró ningún trabajador con el identificador " + identificador);
        }
    }
    
    // Método para mostrar la nómina de un trabajador
    private static void mostrarNomina() {
        System.out.println("Ingrese el identificador del trabajador para mostrar su nómina: ");
        String identificador = in.nextLine();
        in.nextLine();
        
        try{
            Trabajador trabajador = arrayTrabajadores.getTrabajador(identificador);
            
            String nombre = trabajador.getNombre();
            String clase = trabajador.getClass().getSimpleName();
            String departamento = trabajador.getDepartamento().getNombre();
            double sueldoBase = trabajador.calcularSueldoBase(sueldoBaseMaximo);
            int horasExtra = trabajador.getHorasExtra();
            double valorHoraExtra = sueldoBase / 160;
            
            double nomina = sueldoBase + (horasExtra * valorHoraExtra);
            
            System.out.println("Nombre del trabajador: " + nombre);
            System.out.println("Clase del trabajador: " + clase);
            System.out.println("Departamento: " + departamento);
            System.out.println("Sueldo base: " + sueldoBase);
            System.out.println("Horas extra realizadas: " + horasExtra);
            System.out.println("Sueldo total: " + nomina);
            
        }catch (Exception e) {
        System.out.println("Error: No se encontró ningún trabajador con el identificador " + identificador);
        }
    }
    
    // Método para mostrar el número de trabajadores y el pago total en nóminas de todos los trabajadores de un mismo departamento
    private static void mostrarTotalDepartamento() {
        // Obtenemos todos los trabajadores
        Trabajador[] trabajadores = arrayTrabajadores.getTrabajadores();
        
        // Inicializamos un array para almacenar el tetal de nóminas por departamentos
        double[] totalNominasPorDepartamento = new double [trabajadores.length];
        
        // Inicializar un array para almacenar el número de trabajadores por departamento
        int[] totalTrabajadoresPorDepartamento = new int[trabajadores.length];
    
        // Iterar sobre cada trabajador para calcular el total de nóminas y el número de trabajadores por departamento
        for (Trabajador trabajador : trabajadores) {
            //String nombreDepartamento = trabajador.getDepartamento().getNombre();
            double sueldoBase = trabajador.calcularSueldoBase(sueldoBaseMaximo);
            double valorHoraExtra = sueldoBase /160;
            double nomina = sueldoBase + (trabajador.getHorasExtra() * valorHoraExtra);
            
            // Obtener el departamento del trabajador
            Departamento departamento = trabajador.getDepartamento();
            int indexDepartamento = obtenerIndexDepartamento(departamento, trabajadores.length);
            
            //Sumar la nómina al total del departamento correspondiente
            totalNominasPorDepartamento[indexDepartamento] += nomina;
            
            // Incrementa el contador de trabajadores para el departamento
            totalTrabajadoresPorDepartamento[indexDepartamento]++;
        }
        
        // Mostrar el total de nóminas y el número de trabajadores por departamento
        for (int i = 0; i < totalNominasPorDepartamento.length; i++) {
            System.out.println("Departamento: " + trabajadores[i].getDepartamento().getNombre());
            System.out.println("Total de trabajadores: " + totalTrabajadoresPorDepartamento[i]);
            System.out.println("Total de nóminas: " + totalNominasPorDepartamento[i]);
            System.out.println("------------------------------------------");
        }
    }
    
    // Método para mostrar el menú y obtener la opción del usuario
    public static int menu(){
        System.out.println("\n1. Establecer el sueldo máximo de la Empresa");
        System.out.println("2. Añadir un nuevo trabajador a la empresa");
        System.out.println("3. Mostrar los datos de todos los trabajadores de la Empresa");
        System.out.println("4. Modificar el número de horas extraordinarias de un trabajador");
        System.out.println("5. Mostrar la nómina de un trabajador");
        System.out.println("6. Mostrar el número de trabajadores y el pago total en nóminas de todos los trabajadores de un mismo dpto.");
        System.out.println("7. Salir");
        int input = in.nextInt();
        in.nextLine();
        return input;
    }
    
    // Método auxiliar para obtener el índice del departamento en el array
    private static int obtenerIndexDepartamento(Departamento departamento, int totalDepartamentos) {
        Trabajador[] trabajadores = arrayTrabajadores.getTrabajadores();
        for (int i = 0; i < totalDepartamentos; i++) {
            if (trabajadores[i].getDepartamento().equals(departamento)) {
                return i;
            }
        }
    return -1;
    }
}
