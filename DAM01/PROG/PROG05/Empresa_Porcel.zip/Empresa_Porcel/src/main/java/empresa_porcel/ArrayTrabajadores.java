/**
 * Esta clase representa un contenedor para almacenar trabajadores.
 * Proporciona métodos para agregar trabajadores, obtener un trabajador por identificador,
 * y obtener todos los trabajadores almacenados.
 * Utiliza un array de tamaño fijo para almacenar los trabajadores.
 */
package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */
import java.util.Arrays;
public class ArrayTrabajadores {
    
    private static final int MAX_TRABAJADORES = 8; // Número máximo de trabajadores que puede contener el array
    private Trabajador[] trabajadores; // Array para almacenar los trabajadores
    private int numTrabajadores; // Número actual de trabajadores almacenados en el array
    
    // Constructor de la clase ArrayTrabajadores
    public ArrayTrabajadores() {
        this.trabajadores = new Trabajador[MAX_TRABAJADORES];
        this.numTrabajadores = 0;
    }
    
    /**
     * Método para agregar un nuevo trabajador al array.
     * @param trabajador El trabajador a agregar.
     * @return true si se agregó correctamente, false si el array está lleno.
     */
    public boolean addTrabajador(Trabajador trabajador){
        if (numTrabajadores < MAX_TRABAJADORES){
            trabajadores[numTrabajadores] = trabajador;
            numTrabajadores++;
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Método para obtener un trabajador por su identificador.
     * @param identificador El identificador del trabajador a buscar.
     * @return El trabajador con el identificador especificado.
     * @throws Exception Si no se encuentra ningún trabajador con el identificador especificado.
     */
    public Trabajador getTrabajador(String identificador) throws Exception {
        for (int i = 0; i < numTrabajadores; i++) {
            if (trabajadores[i].getIdentificador().equals(identificador)) {
                return trabajadores[i]; // Devuelve una copia del trabajador para preservar la integridad de los datos
            }
        } throw new Exception("Trabajador no encontrado con el identificador: " + identificador);
    }
    
    /**
     * Método para obtener todos los trabajadores almacenados en el array.
     * @return Un array con todos los trabajadores.
     */
    public Trabajador[] getTrabajadores() {
        return Arrays.copyOf(trabajadores, numTrabajadores); // Devuelve una copia del array de trabajadores para preservar la integridad de los datos
    }
}
