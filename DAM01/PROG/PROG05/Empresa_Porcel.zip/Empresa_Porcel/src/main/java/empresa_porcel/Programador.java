/*
 * Esta clase representa a un Programador, que es un tipo de trabajador en la empresa.
 * Extiende la clase Trabajador e incluye información adicional específica para un Programador, como el lenguaje de programación.
 */
package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */

public class Programador extends Trabajador {
    private String lenguaje;
    
    public Programador (String nombre, String mail, String telefono, Departamento departamento, String identificador, int horasExtra, String lenguaje){
        super(nombre, mail, telefono, departamento, identificador, horasExtra);
        this.lenguaje = lenguaje;
    }

    @Override
    public double calcularSueldoBase(double sueldoBaseMaximo){
        return sueldoBaseMaximo * 0.4; 
    }

    /**
     * @return the lenguaje
     */
    public String getLenguaje() {
        return lenguaje;
    }

    /**
     * @param lenguaje the lenguaje to set
     */
    public void setLenguaje(String lenguaje) {
        this.lenguaje = lenguaje;
    }
}
