/*
 * Esta clase representa a un Gestor, que es un tipo de trabajador en la empresa.
 * Extiende la clase Trabajador e incluye información adicional específica para un Gestor, como la especialidad.
 */
package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */
public class Gestor extends Trabajador {
    private String especialidad;
    
    public Gestor (String nombre, String mail, String telefono, Departamento departamento, String identificador, int horasExtra, String especialidad){
        super(nombre, mail, telefono, departamento, identificador, horasExtra);
        this.especialidad = especialidad;
    }
    
    @Override
    public double calcularSueldoBase(double sueldoBaseMaximo){
        
        return sueldoBaseMaximo * 0.7;
        
    }

    /**
     * @return the especialidad
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * @param especialidad the especialidad to set
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
