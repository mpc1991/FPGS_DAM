/*
 * Esta clase representa un Trabajador en la empresa.
 * Es una clase abstracta que proporciona funcionalidades comunes para todos los trabajadores,
 * como la gestión de datos personales y el cálculo del identificador.
 */
package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */
import java.time.*;

public abstract class Trabajador {
    private String nombre, mail, telefono;
    private Departamento departamento; //atributo de composición
    private String identificador;
    private int horasExtra;

    public Trabajador(String nombre, String mail, String telefono, Departamento departamento, String identificador, int horasExtra){
        this.nombre = nombre;
        this.mail = mail;
        this.telefono = telefono;
        this.departamento = departamento;
        this.horasExtra = horasExtra;
        this.identificador = calcularIdentificador();
    }

    // Método para calcular el identificador
    private String calcularIdentificador() {
        String anioActual = String.valueOf(Year.now().getValue());
        String abreviaturaDepartamento = this.departamento.getNombre().substring(0, Math.min(3, this.departamento.getNombre().length()));
        String abreviaturaNombre = this.nombre.substring(0, Math.min(3, this.nombre.length()));
        return anioActual + abreviaturaDepartamento.toUpperCase() + abreviaturaNombre.toUpperCase();
    }
    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the departamento
     */
    public Departamento getDepartamento() {
        return departamento;
    }

    /**
     * @param departamento the departamento to set
     */
    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the horasExtra
     */
    public int getHorasExtra() {
        return horasExtra;
    }

    /**
     * @param horasExtra the horasExtra to set
     */
    public void setHorasExtra(int horasExtra) {
        this.horasExtra = horasExtra;
    }
    
    public abstract double calcularSueldoBase(double sueldoBaseMaximo);
}
