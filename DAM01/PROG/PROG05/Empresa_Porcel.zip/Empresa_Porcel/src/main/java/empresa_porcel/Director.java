/*
 * Esta clase representa a un Director, que es un tipo de trabajador en la empresa.
 * Extiende la clase Trabajador e incluye información adicional específica para un Director, como la antigüedad.
 */
package empresa_porcel;

/**
 *
 * @author Macia Porcel Cifre
 */
public class Director extends Trabajador {
    private int antiguedad;
    
    public Director (String nombre, String mail, String telefono, Departamento departamento, String identificador, int horasExtra, int antiguedad){
        super(nombre, mail, telefono, departamento, identificador, horasExtra);
        this.antiguedad = antiguedad;
    }

    @Override
    public double calcularSueldoBase(double sueldoBaseMaximo){
        return sueldoBaseMaximo + (45*antiguedad); 
    }

    /**
     * @return the antiguedad
     */
    public int getAntiguedad() {
        return antiguedad;
    }

    /**
     * @param antiguedad the antiguedad to set
     */
    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }
}
