package com.porcel.psp04_porcel_cifre_macia.services;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;


@ApplicationPath("api")
public class Configuration extends Application {

}
