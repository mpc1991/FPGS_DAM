package com.porcel;

import com.porcel.data.Cliente;

public class Main {

    public static void main(String[] args) {
        Cliente cliente = new Cliente();
    }
}
