/* BARREL FILE
  Aquest fitxer contindrà les exportacions de totes les classes que anirem
  creant dintre del directori screen.
  Després simplemenrt haurem de fer UN SOL import d'aquest fitxer.
*/
export 'package:movies_app/widgets/card_swiper.dart';
export 'package:movies_app/widgets/casting_cards.dart';
export 'package:movies_app/widgets/movie_slider.dart';
