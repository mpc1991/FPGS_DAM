export 'package:preferences_app_plantilla/screens/home_screen.dart';
export 'package:preferences_app_plantilla/screens/settings_screen.dart';
