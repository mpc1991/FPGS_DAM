package com.example.preferences_app_plantilla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
