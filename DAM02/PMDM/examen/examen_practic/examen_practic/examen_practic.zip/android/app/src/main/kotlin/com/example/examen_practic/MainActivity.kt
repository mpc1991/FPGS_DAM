package com.example.examen_practic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
