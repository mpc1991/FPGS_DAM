package com.example.qr_scan_plantilla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
