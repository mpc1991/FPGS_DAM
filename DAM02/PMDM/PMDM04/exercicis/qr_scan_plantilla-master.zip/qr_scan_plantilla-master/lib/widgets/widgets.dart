export 'package:qr_scan/widgets/custom_navigatorbar.dart';
export 'package:qr_scan/widgets/scan_bottom.dart';
