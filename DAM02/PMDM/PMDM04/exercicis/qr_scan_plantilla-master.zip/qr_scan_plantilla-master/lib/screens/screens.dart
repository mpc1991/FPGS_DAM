export 'package:qr_scan/screens/home_screen.dart';
export 'package:qr_scan/screens/mapa_screen.dart';
export 'package:qr_scan/screens/mapas_screen.dart';
export 'package:qr_scan/screens/direccions_screen.dart';
